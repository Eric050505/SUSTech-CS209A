import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Collectors;


public class OlympicsAnalyzer implements OlympicsAnalyzerInterface {

    private final Map<String, List<String[]>> dataMap;

    public OlympicsAnalyzer(String datasetPath) {

        dataMap = new HashMap<>();

        try {
            List<Path> csvFiles = Files.walk(Paths.get(datasetPath)).filter(Files::isRegularFile).filter(path -> path.toString().endsWith(".csv")).toList();
            for (Path csvFile : csvFiles) {
                String fileName = csvFile.getFileName().toString().split(".csv")[0];
                dataMap.put(fileName, new ArrayList<>());
                try (BufferedReader bufferedReader = new BufferedReader(new FileReader(csvFile.toFile()))) {
                    String line;
                    char[] chars;
                    while ((line = bufferedReader.readLine()) != null) {
                        chars = line.toCharArray();
                        line = "";
                        for (int i = 0; i < chars.length; i++)
                            if (chars[i] == '"') {
                                i++;
                                while (i < chars.length && chars[i] != '"') {
                                    if (chars[i] == ',') chars[i] = '\0';
                                    i++;
                                }
                            }
                        for (char aChar : chars)
                            line = line.concat(String.valueOf(aChar));
                        String[] token = line.split(",");
                        dataMap.get(fileName).add(token);
                    }
                }
            }
            for (Map.Entry<String, List<String[]>> entry : dataMap.entrySet())
                entry.getValue().remove(0);
        } catch (IOException e) {
            System.out.println("Error occurs when read files: " + e.getMessage());
        }
    }

    public List<String[]> getDataset(String fileName) {
        return dataMap.get(fileName);
    }

    @Override
    public Map<String, Integer> topPerformantFemale() {
        List<String[]> femaleData = filter(getDataset("Olympic_Athlete_Bio_filtered"), s -> s[2].equals("Female"));
        Set<String> femaleSet = new HashSet<>();
        for (String[] data : femaleData)
            femaleSet.add(data[1]);

        List<String[]> athleteEventData = getDataset("Olympic_Athlete_Event_Results");
        Map<String, Integer> topFemale = new HashMap<>();
        for (String[] data : athleteEventData) {
            if (femaleSet.contains(data[6]) && data[9].equals("Gold") && data[10].equals("False")) {
                if (topFemale.get(data[6]) == null) {
                    topFemale.put(data[6], 1);
                } else topFemale.replace(data[6], topFemale.get(data[6]) + 1);
            }
        }

        return topFemale.entrySet().stream()
                .sorted(Map.Entry.<String, Integer>comparingByValue(Comparator.reverseOrder())
                        .thenComparing(Map.Entry.comparingByKey()))
                .limit(10)
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e) -> e1, LinkedHashMap::new));
    }

    @Override
    public Map<String, Float> bmiBySports() {
        List<String[]> athleteData = getDataset("Olympic_Athlete_Bio_filtered");
        Map<String, Float> athleteBMI = new HashMap<>();
        for (String[] data : athleteData) {
            if (!data[4].isEmpty() && !data[5].isEmpty()) {
                float height = Float.parseFloat(data[4]);
                float weight = Float.parseFloat(data[5]);
                float BMI = 10000 * weight / (height * height);
                athleteBMI.put(data[0], BMI);
            }
        }

        List<String[]> athleteEventData = getDataset("Olympic_Athlete_Event_Results");
        Map<String, Set<String>> sportsAthlete = new HashMap<>();
        for (String[] data : athleteEventData) {
            sportsAthlete.computeIfAbsent(data[3], e2 -> new HashSet<>());
            if (athleteBMI.containsKey(data[7]))
                sportsAthlete.get(data[3]).add(data[7]);
        }

        Map<String, List<Float>> sportsAthleteBMI = new HashMap<>();
        for (Map.Entry<String, Set<String>> entry : sportsAthlete.entrySet()) {
            sportsAthleteBMI.computeIfAbsent(entry.getKey(), e -> new ArrayList<>());
            for (String data : entry.getValue())
                sportsAthleteBMI.get(entry.getKey()).add(athleteBMI.get(data));
        }

        Map<String, Float> sportsAvgBMI = new HashMap<>();
        float sum, avg;
        for (Map.Entry<String, List<Float>> entry : sportsAthleteBMI.entrySet()) {
            if (!entry.getValue().isEmpty()) {
                String sport = entry.getKey();
                sum = 0;
                for (Float bmi : entry.getValue())
                    sum += bmi;
                avg = sum / entry.getValue().size();
                sportsAvgBMI.put(sport, Float.parseFloat(String.format("%.1f", avg)));
            }
        }

        return sportsAvgBMI.entrySet().stream()
                .sorted(Map.Entry.<String, Float>comparingByValue(Comparator.reverseOrder())
                        .thenComparing(Map.Entry.comparingByKey()))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e) -> e1, LinkedHashMap::new));
    }

    @Override
    public Map<String, Set<Integer>> leastAppearedSport() {
        List<String[]> athleteEventData = getDataset("Olympic_Athlete_Event_Results");
        Map<String, Set<Integer>> leastAppearedSports = new HashMap<>();
        for (String[] data : athleteEventData) {
            if (data[0].split(" ")[1].equals("Summer")) {
                leastAppearedSports.computeIfAbsent(data[3], e -> new HashSet<>());
                leastAppearedSports.get(data[3]).add(Integer.parseInt(data[0].split(" ")[0]));
            }
        }

        return leastAppearedSports.entrySet().stream()
                .sorted(Comparator.comparingInt(
                                (Map.Entry<String, Set<Integer>> e) -> e.getValue().size())
                        .thenComparing(Map.Entry.comparingByKey()))
                .limit(10)
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e) -> e1, LinkedHashMap::new));
    }

    @Override
    public Map<String, Integer> winterMedalsByCountry() {
        List<String[]> medalData = filter(getDataset("Olympic_Games_Medal_Tally"),
                e -> e[0].split(" ")[1].equals("Winter") && Integer.parseInt(e[2]) >= 2000);
        Map<String, List<Integer>> countryMedals = new HashMap<>();
        for (String[] data : medalData) {
            countryMedals.computeIfAbsent(data[4], e -> new ArrayList<>());
            countryMedals.get(data[4]).add(Integer.parseInt(data[8]));
        }

        Map<String, Integer> winterMedals = new HashMap<>();
        int sum;
        for (Map.Entry<String, List<Integer>> entry : countryMedals.entrySet()) {
            sum = 0;
            for (Integer medal : entry.getValue())
                sum += medal;
            winterMedals.put(entry.getKey(), sum);
        }

        return winterMedals.entrySet().stream()
                .sorted(Map.Entry.<String, Integer>comparingByValue(Comparator.reverseOrder())
                        .thenComparing(Map.Entry.comparingByKey()))
                .limit(10)
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e) -> e1, LinkedHashMap::new));
    }

    @Override
    public Map<String, Integer> topCountryWithYoungAthletes() {
        List<String[]> athletesData = getDataset("Olympic_Athlete_Bio_filtered");
        Map<Integer, Integer> ageMap = new HashMap<>();
        String[] born;
        int age;
        for (String[] data : athletesData) {
            if (!data[3].isEmpty()) {
                born = data[3].split(" ");
                age = Integer.parseInt(born[born.length - 1]);
                ageMap.put(Integer.parseInt(data[0]), 2020 - age);
            }
        }

        List<String[]> countryCodeData = getDataset("Olympics_Country");
        Map<String, String> countryCodeMap = new HashMap<>();
        for (String[] data : countryCodeData)
            countryCodeMap.put(data[0], data[1]);
        List<String[]> partData = filter(getDataset("Olympic_Athlete_Event_Results"), e -> e[1].equals("61"));
        Map<String, Set<String>> countryAthleteMap = new HashMap<>();
        for (String[] data : partData) {
            countryAthleteMap.computeIfAbsent(data[2], e -> new HashSet<>());
            if (ageMap.get(Integer.parseInt(data[7])) != null)
                countryAthleteMap.get(data[2]).add(data[7]);
        }

        Map<String, Integer> youngAges = new HashMap<>();
        float sum, avg;
        for (Map.Entry<String, Set<String>> entry : countryAthleteMap.entrySet()) {
            if (!entry.getValue().isEmpty()) {
                sum = 0;
                for (String code : entry.getValue())
                    sum += ageMap.get(Integer.parseInt(code));
                avg = sum / entry.getValue().size();
                youngAges.put(countryCodeMap.get(entry.getKey()), Math.round(avg));
            }
        }

        return youngAges.entrySet().stream()
                .sorted(Map.Entry.<String, Integer>comparingByValue()
                        .thenComparing(Map.Entry.comparingByKey()))
                .limit(10)
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e) -> e1, LinkedHashMap::new));
    }

    public static List<String[]> filter(List<String[]> list, Predicate predicate) {
        ArrayList<String[]> filteredList = new ArrayList<>();
        for (String[] s : list) {
            if (predicate.test(s)) filteredList.add(s);
        }
        return filteredList;
    }

}

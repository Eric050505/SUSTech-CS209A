public interface Predicate {
    boolean test(String[] s);
}
